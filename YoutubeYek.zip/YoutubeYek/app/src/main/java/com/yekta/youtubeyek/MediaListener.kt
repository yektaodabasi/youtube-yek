package com.yekta.youtubeyek

import android.content.ComponentName
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

/**
 * Android, başka uygulamaların medya oturumlarını yalnızca "bildirim erişimi" verilmiş uygulamalara açar.
 * Bu servis o izni taşır; YouTube bildirimi gelip gittikçe oynatıcı bilgisini tazeler. Bildirimleri kaydetmez.
 */
class MediaListener : NotificationListenerService() {

    override fun onListenerConnected() {
        PlayerHub.start(this)
    }

    override fun onListenerDisconnected() {
        NotificationListenerService.requestRebind(ComponentName(this, MediaListener::class.java))
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn != null && Prefs.isAllowed(this, sbn.packageName)) PlayerHub.start(this)
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) {
        if (sbn != null && Prefs.isAllowed(this, sbn.packageName)) PlayerHub.start(this)
    }
}
