package com.yekta.youtubeyek

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadata
import android.os.Handler
import android.os.Looper
import java.net.HttpURLConnection
import java.net.URL

/**
 * Büyük kapak görünümü için yüksek çözünürlüklü kapak.
 * Medya oturumunun verdiği kapak resmi genelde küçüktür; oturum bir resim adresi ya da
 * YouTube video kimliği veriyorsa aynı kapağın büyüğü arka planda indirilir.
 * Yalnızca son parçanın kapağı bellekte tutulur. İnemezse küçük kapak kullanılmaya devam eder.
 */
object HiResArt {

    private val main = Handler(Looper.getMainLooper())
    private val videoId = Regex("^[A-Za-z0-9_-]{11}$")

    private var key: String? = null
    private var bitmap: Bitmap? = null
    private var loadingKey: String? = null

    /** Hazırsa büyük kapağı döner; değilse indirmeyi başlatır, bitince [onReady] çağrılır. */
    fun request(md: MediaMetadata?, onReady: () -> Unit): Bitmap? {
        if (md == null) return null
        val urls = candidates(md)
        if (urls.isEmpty()) return null
        val k = urls.first()
        if (k == key) return bitmap
        if (k == loadingKey) return null
        loadingKey = k
        Thread {
            var result: Bitmap? = null
            for (u in urls) {
                result = fetch(u)
                if (result != null) break
            }
            main.post {
                if (loadingKey == k) loadingKey = null
                key = k
                bitmap = result
                if (result != null) onReady()
            }
        }.start()
        return null
    }

    private fun candidates(md: MediaMetadata): List<String> {
        val out = ArrayList<String>()
        for (k in listOf(
            MediaMetadata.METADATA_KEY_ART_URI,
            MediaMetadata.METADATA_KEY_ALBUM_ART_URI,
            MediaMetadata.METADATA_KEY_DISPLAY_ICON_URI
        )) {
            val u = md.getString(k)
            if (u != null && u.startsWith("https://")) out.add(u)
        }
        val id = md.getString(MediaMetadata.METADATA_KEY_MEDIA_ID)
        if (id != null && videoId.matches(id)) {
            out.add("https://i.ytimg.com/vi/$id/maxresdefault.jpg")
            out.add("https://i.ytimg.com/vi/$id/hqdefault.jpg")
        }
        return out
    }

    private fun fetch(url: String): Bitmap? = try {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 5000
        c.readTimeout = 8000
        try {
            if (c.responseCode != 200) null
            else c.inputStream.use { BitmapFactory.decodeStream(it) }?.takeIf { it.width >= 200 }
        } finally {
            c.disconnect()
        }
    } catch (e: Exception) {
        null
    }
}
