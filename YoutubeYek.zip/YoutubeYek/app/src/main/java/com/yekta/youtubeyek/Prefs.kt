package com.yekta.youtubeyek

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Color

/** Tüm ayarlar tek yerde. Uygulama ekranı yazar; kart ve kilit ekranı servisi değişiklikleri anında dinler. */
object Prefs {
    const val FILE = "youtubeyek"

    const val ENABLED = "enabled"          // kilit ekranı kartı açık/kapalı
    const val ALPHA = "alpha_pct"          // arka plan şeffaflığı %0..90
    const val COLOR = "color_idx"          // arka plan rengi
    const val TEXT = "text_pct"            // yazı boyutu %80..140
    const val TOP = "top_pct"              // kartın üst kenarı, ekran yüksekliğinin %'si
    const val SIDE = "side_dp"             // sağ-sol boşluk (dp)
    const val QUEUE = "queue_open"         // çalma listesi açık mı
    const val ROWS = "queue_rows"          // listede görünen satır sayısı
    const val HIDE_PAUSED = "hide_paused"  // duraklatınca gizle
    const val MUSIC = "include_music"      // YouTube Music de dahil
    const val TOUCH_HIDE = "touch_hide"    // kilit ekranında başka yere dokununca gizle
    const val DIAG = "diag"                // tanılama kaydı

    val ACCENT: Int = 0xFFFF4E45.toInt()

    val YOUTUBE = setOf("com.google.android.youtube", "app.revanced.android.youtube")
    val MUSIC_PKGS = setOf("com.google.android.apps.youtube.music", "app.revanced.android.apps.youtube.music")

    class Swatch(val name: String, val color: Int)

    val SWATCHES = listOf(
        Swatch("Koyu", 0xFF171B24.toInt()),
        Swatch("Siyah", 0xFF000000.toInt()),
        Swatch("Lacivert", 0xFF0E1A3A.toInt()),
        Swatch("Bordo", 0xFF4B0F1C.toInt()),
        Swatch("Beyaz", 0xFFF2F2F2.toInt())
    )

    private val INT_DEFAULTS = mapOf(
        ALPHA to 15, COLOR to 0, TEXT to 100, TOP to 25, SIDE to 14, ROWS to 3
    )
    private val BOOL_DEFAULTS = mapOf(
        ENABLED to true, QUEUE to true, HIDE_PAUSED to false, MUSIC to true, TOUCH_HIDE to true
    )

    fun sp(c: Context): SharedPreferences = c.applicationContext.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    fun i(c: Context, key: String): Int = sp(c).getInt(key, INT_DEFAULTS[key] ?: 0)
    fun b(c: Context, key: String): Boolean = sp(c).getBoolean(key, BOOL_DEFAULTS[key] ?: false)

    fun put(c: Context, key: String, v: Int) = sp(c).edit().putInt(key, v).apply()
    fun put(c: Context, key: String, v: Boolean) = sp(c).edit().putBoolean(key, v).apply()

    fun allowedPackages(c: Context): Set<String> =
        if (b(c, MUSIC)) YOUTUBE + MUSIC_PKGS else YOUTUBE

    fun isAllowed(c: Context, pkg: String?): Boolean = pkg != null && pkg in allowedPackages(c)

    class CardStyle(
        val bg: Int,
        val transparencyPct: Int,
        val textPct: Int,
        val rows: Int,
        val queueOpen: Boolean
    ) {
        val light: Boolean
            get() = (Color.red(bg) * 299 + Color.green(bg) * 587 + Color.blue(bg) * 114) / 1000 > 150
        val primary: Int
            get() = if (light) 0xFF14161B.toInt() else Color.WHITE
        val secondary: Int
            get() = if (light) 0xFF5A5F6B.toInt() else 0xFFB4B9C4.toInt()
    }

    fun style(c: Context): CardStyle {
        val idx = i(c, COLOR).coerceIn(0, SWATCHES.size - 1)
        return CardStyle(
            bg = SWATCHES[idx].color,
            transparencyPct = i(c, ALPHA).coerceIn(0, 90),
            textPct = i(c, TEXT).coerceIn(80, 140),
            rows = i(c, ROWS).coerceIn(1, 8),
            queueOpen = b(c, QUEUE)
        )
    }
}
