package com.yekta.youtubeyek

import android.app.Activity
import android.app.NotificationManager
import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ClipboardManager
import android.content.ComponentName
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import kotlin.math.roundToInt

private const val M = ViewGroup.LayoutParams.MATCH_PARENT
private const val W = ViewGroup.LayoutParams.WRAP_CONTENT

/** Ayarlar / kontrol paneli. Tüm arayüz kodla kurulur. */
class MainActivity : Activity() {

    private val bgColor = 0xFF0D0F14.toInt()
    private val panelColor = 0xFF171A22.toInt()
    private val textPrimary = Color.WHITE
    private val textSecondary = 0xFFA7ADBA.toInt()
    private val sectionColor = 0xFFFFC233.toInt()
    private val okColor = 0xFF4CD07D.toInt()
    private val badColor = 0xFFFF6B6B.toInt()

    private lateinit var root: LinearLayout
    private lateinit var preview: PlayerCardView
    private lateinit var notifStatus: TextView
    private lateinit var a11yStatus: TextView
    private lateinit var batteryStatus: TextView
    private lateinit var diagText: TextView
    private val swatchDots = ArrayList<View>()

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).roundToInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bgColor
        window.navigationBarColor = bgColor

        val scroll = ScrollView(this)
        scroll.setBackgroundColor(bgColor)
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(22), dp(18), dp(40))
        }
        scroll.addView(root, FrameLayout.LayoutParams(M, W))
        setContentView(scroll)
        build()
    }

    override fun onResume() {
        super.onResume()
        PlayerHub.start(this)
        refreshStatus()
        preview.render()
        refreshDiag()
    }

    // ------------------------------------------------------------------ ekran

    private fun build() {
        root.addView(label("YoutubeYek", 26f, textPrimary, bold = true))
        root.addView(
            label(
                "YouTube çalarken kilit ekranında, saat ile parmak izi arasında kontrol tuşlu bir oynatıcı kartı gösterir.",
                14f, textSecondary
            ),
            lp(top = 4)
        )

        // 1 · İzinler
        section("İzinler")
        notifStatus = permissionRow(
            "1. Bildirim erişimi",
            "Çalan video/şarkının adını, kapağını ve listesini okumak için.",
            "Aç"
        ) { openNotificationAccess() }
        a11yStatus = permissionRow(
            "2. Erişilebilirlik hizmeti",
            "Kartı kilit ekranının üstüne çizebilmek için. Açılan sayfada anahtara dokun. \"Kısıtlanmış ayar\" uyarısı çıkarsa Tamam de, sonra Ayarlar › Uygulamalar › YoutubeYek › ⋮ › \"Kısıtlanmış ayarlara izin ver\".",
            "Aç"
        ) { openAccessibility() }
        batteryStatus = permissionRow(
            "3. Pil kısıtlaması",
            "Telefon uygulamayı arka planda kapatmasın diye.",
            "Kaldır"
        ) { openBattery() }

        // Önizleme
        section("Önizleme")
        val stage = FrameLayout(this)
        stage.background = GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            intArrayOf(0xFF3B2C05.toInt(), 0xFF3A0A12.toInt(), 0xFF07080B.toInt())
        ).apply { cornerRadius = dp(18).toFloat() }
        stage.setPadding(dp(10), dp(14), dp(10), dp(14))
        preview = PlayerCardView(this).apply { sampleWhenEmpty = true }
        stage.addView(preview, FrameLayout.LayoutParams(M, W))
        root.addView(stage, lp(top = 8))
        root.addView(
            label("YouTube'da bir şey çalıyorsa önizlemede o görünür ve tuşlar çalışır.", 12.5f, textSecondary),
            lp(top = 6)
        )

        // Görünüm
        section("Görünüm")
        val look = panel()
        slider(look, "Arka plan şeffaflığı", Prefs.ALPHA, 0, 90) { "%$it" }
        colorRow(look)
        slider(look, "Yazı boyutu", Prefs.TEXT, 80, 140) { "%$it" }

        // Konum
        section("Konum")
        val pos = panel()
        slider(pos, "Dikey konum (ekranın üstünden)", Prefs.TOP, 5, 75) { "%$it" }
        slider(pos, "Kenar boşluğu", Prefs.SIDE, 0, 48) { "$it dp" }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(button("Konumu göster (10 sn)") {
            val s = LockOverlayService.instance
            if (s == null) needAccessibility() else s.showPreview(10_000L)
        }, LinearLayout.LayoutParams(0, W, 1f))
        row.addView(button("Kilitle ve dene") {
            val s = LockOverlayService.instance
            when {
                s == null -> needAccessibility()
                PlayerHub.controller == null -> toast("Önce YouTube'da bir video ya da şarkı başlat.")
                else -> s.lockNow()
            }
        }, LinearLayout.LayoutParams(0, W, 1f).apply { marginStart = dp(8) })
        pos.addView(row, lp(top = 10))
        pos.addView(
            label(
                "İpucu: Kartın alt kenarı parmak izi simgesine değmesin. Liste açıkken kart uzar; satır sayısını azaltabilirsin.",
                12.5f, textSecondary
            ),
            lp(top = 6)
        )

        // Çalma listesi
        section("Çalma listesi")
        val q = panel()
        switchRow(q, "Çalma listesini göster", Prefs.QUEUE, "Karttaki ok tuşuyla da açılıp kapanır.")
        slider(q, "Görünen satır sayısı", Prefs.ROWS, 1, 8) { "$it" }
        q.addView(
            label(
                "Liste, YouTube'un paylaştığı kadarıyla gösterilir. YouTube bazı oynatmalarda listeyi paylaşmaz; o zaman kartta \"Liste bilgisi yok\" yazar.",
                12.5f, textSecondary
            ),
            lp(top = 6)
        )

        // Davranış
        section("Davranış")
        val d = panel()
        switchRow(d, "Kilit ekranı kartı açık", Prefs.ENABLED)
        switchRow(d, "YouTube Music'te de göster", Prefs.MUSIC)
        switchRow(d, "Duraklatınca gizle", Prefs.HIDE_PAUSED)
        switchRow(
            d, "Kilit ekranında başka yere dokununca gizle", Prefs.TOUCH_HIDE,
            "Kilidi açmak için kaydırınca ya da bildirim panelini indirince kart üstte kalmasın diye. Ekran bir sonraki açılışta kart yine görünür."
        )

        // İpuçları
        section("Sistemin kendi kutusu")
        val tip = panel()
        tip.addView(
            label(
                "Kilit ekranında YouTube'un kendi kutusu da çıkıyorsa: Ayarlar › Bildirimler ve Durum çubuğu › \"Bildirimi kilit ekranında göster\"i kapat. Böylece kilit ekranında yalnızca bu kart kalır.",
                13f, textPrimary
            )
        )
        tip.addView(
            label(
                "Android 13 ve üstünde izin anahtarı gri ve açılmıyorsa: Ayarlar › Uygulamalar › YoutubeYek › sağ üstteki ⋮ › \"Kısıtlanmış ayarlara izin ver\", sonra tekrar dene.",
                12.5f, textSecondary
            ),
            lp(top = 8)
        )

        // Tanılama
        section("Tanılama")
        val dg = panel()
        dg.addView(
            label(
                "Kart kilit ekranında hiç çıkmıyor ya da yanlış anda çıkıyorsa: YouTube çalarken ekranı kilitle, açıp kapat, sonra buraya gelip \"Kopyala\"ya bas ve metni bana gönder.",
                12.5f, textSecondary
            )
        )
        diagText = label("", 11f, textSecondary).apply {
            typeface = Typeface.MONOSPACE
            setTextIsSelectable(true)
        }
        dg.addView(diagText, lp(top = 8))
        val drow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        drow.addView(button("Yenile") { refreshDiag() }, LinearLayout.LayoutParams(0, W, 1f))
        drow.addView(button("Kopyala") { copyDiag() }, LinearLayout.LayoutParams(0, W, 1f).apply { marginStart = dp(8) })
        dg.addView(drow, lp(top = 8))
    }

    // ------------------------------------------------------------------ yapı taşları

    private fun lp(top: Int = 0): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(M, W).apply { topMargin = dp(top) }

    private fun label(text: String, sp: Float, color: Int, bold: Boolean = false): TextView =
        TextView(this).apply {
            this.text = text
            setTextColor(color)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
            if (bold) typeface = Typeface.DEFAULT_BOLD
            setLineSpacing(0f, 1.1f)
        }

    private fun section(title: String) {
        root.addView(label(title.uppercase(), 13f, sectionColor, bold = true), lp(top = 26))
    }

    private fun panel(): LinearLayout {
        val p = LinearLayout(this)
        p.orientation = LinearLayout.VERTICAL
        p.background = GradientDrawable().apply {
            setColor(panelColor)
            cornerRadius = dp(16).toFloat()
        }
        p.setPadding(dp(14), dp(10), dp(14), dp(14))
        root.addView(p, lp(top = 8))
        return p
    }

    private fun button(text: String, action: () -> Unit): Button =
        Button(this).apply {
            this.text = text
            isAllCaps = false
            setOnClickListener { action() }
        }

    private fun permissionRow(title: String, desc: String, btn: String, action: () -> Unit): TextView {
        val p = panel()
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val texts = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        texts.addView(label(title, 15f, textPrimary, bold = true))
        texts.addView(label(desc, 12.5f, textSecondary), lp(top = 2))
        val status = label("", 13f, textSecondary, bold = true)
        texts.addView(status, lp(top = 4))
        row.addView(texts, LinearLayout.LayoutParams(0, W, 1f))
        row.addView(button(btn, action), LinearLayout.LayoutParams(W, W).apply { marginStart = dp(8) })
        p.addView(row)
        return status
    }

    private fun slider(box: LinearLayout, title: String, key: String, minV: Int, maxV: Int, fmt: (Int) -> String) {
        val lbl = label("", 14f, textPrimary)
        box.addView(lbl, lp(top = 8))
        val sb = SeekBar(this)
        sb.min = minV
        sb.max = maxV
        val cur = Prefs.i(this, key).coerceIn(minV, maxV)
        sb.progress = cur
        lbl.text = "$title: ${fmt(cur)}"
        sb.progressTintList = ColorStateList.valueOf(Prefs.ACCENT)
        sb.thumbTintList = ColorStateList.valueOf(Prefs.ACCENT)
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, progress: Int, fromUser: Boolean) {
                lbl.text = "$title: ${fmt(progress)}"
                if (fromUser) Prefs.put(this@MainActivity, key, progress)
            }

            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        box.addView(sb, lp(top = 2))
    }

    private fun switchRow(box: LinearLayout, title: String, key: String, desc: String? = null) {
        val sw = Switch(this)
        sw.text = title
        sw.setTextColor(textPrimary)
        sw.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
        sw.isChecked = Prefs.b(this, key)
        val states = arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf())
        sw.thumbTintList = ColorStateList(states, intArrayOf(Prefs.ACCENT, 0xFFCCCCCC.toInt()))
        sw.trackTintList = ColorStateList(states, intArrayOf(0x88FF4E45.toInt(), 0x55FFFFFF))
        sw.setOnCheckedChangeListener { _, checked -> Prefs.put(this, key, checked) }
        box.addView(sw, lp(top = 8))
        if (desc != null) box.addView(label(desc, 12.5f, textSecondary), lp(top = 0))
    }

    private fun colorRow(box: LinearLayout) {
        box.addView(label("Arka plan rengi", 14f, textPrimary), lp(top = 12))
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        Prefs.SWATCHES.forEachIndexed { i, sw ->
            val col = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
            }
            val dot = View(this)
            col.addView(dot, LinearLayout.LayoutParams(dp(34), dp(34)))
            col.addView(label(sw.name, 11f, textSecondary), LinearLayout.LayoutParams(W, W).apply { topMargin = dp(4) })
            col.setOnClickListener {
                Prefs.put(this, Prefs.COLOR, i)
                paintSwatches()
            }
            swatchDots.add(dot)
            row.addView(col, LinearLayout.LayoutParams(0, W, 1f))
        }
        box.addView(row, lp(top = 8))
        paintSwatches()
    }

    private fun paintSwatches() {
        val sel = Prefs.i(this, Prefs.COLOR)
        swatchDots.forEachIndexed { i, v ->
            v.background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Prefs.SWATCHES[i].color)
                if (i == sel) setStroke(dp(3), Prefs.ACCENT) else setStroke(dp(1), 0x66FFFFFF)
            }
        }
    }

    // ------------------------------------------------------------------ izinler

    private fun notificationAccessGranted(): Boolean =
        getSystemService(NotificationManager::class.java)
            .isNotificationListenerAccessGranted(ComponentName(this, MediaListener::class.java))

    private fun accessibilityEnabled(): Boolean {
        if (LockOverlayService.instance != null) return true
        val s = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
            ?: return false
        val me = ComponentName(this, LockOverlayService::class.java)
        return s.split(':').any { ComponentName.unflattenFromString(it) == me }
    }

    private fun batteryUnrestricted(): Boolean =
        getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(packageName)

    private fun setStatus(v: TextView, ok: Boolean, okText: String = "✓ Açık", badText: String = "✗ Kapalı") {
        v.text = if (ok) okText else badText
        v.setTextColor(if (ok) okColor else badColor)
    }

    private fun refreshStatus() {
        setStatus(notifStatus, notificationAccessGranted())
        setStatus(a11yStatus, accessibilityEnabled())
        setStatus(batteryStatus, batteryUnrestricted(), "✓ Kısıtlama yok", "✗ Pil tasarrufu kısıtlıyor olabilir")
    }

    private fun openNotificationAccess() {
        val detail = Intent(Settings.ACTION_NOTIFICATION_LISTENER_DETAIL_SETTINGS).putExtra(
            Settings.EXTRA_NOTIFICATION_LISTENER_COMPONENT_NAME,
            ComponentName(this, MediaListener::class.java).flattenToString()
        )
        if (!tryStart(detail)) tryStart(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
    }

    /**
     * Önce doğrudan bu servisin kendi ayar sayfasını açmayı dener. Bazı telefonlarda listedeki gri öğe
     * dokunulamaz olsa da bu sayfadaki anahtar "kısıtlanmış ayar" uyarısını gösterir; uyarı bir kez
     * görüldükten sonra Uygulama bilgileri › ⋮ menüsünde "Kısıtlanmış ayarlara izin ver" belirir.
     */
    private fun openAccessibility() {
        val me = ComponentName(this, LockOverlayService::class.java).flattenToString()
        val detail = Intent("android.settings.ACCESSIBILITY_DETAILS_SETTINGS")
            .putExtra(Intent.EXTRA_COMPONENT_NAME, me)
        if (!tryStart(detail)) tryStart(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
    }

    private fun openBattery() {
        val req = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))
        if (!tryStart(req)) tryStart(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
    }

    private fun tryStart(i: Intent): Boolean =
        try {
            startActivity(i)
            true
        } catch (e: ActivityNotFoundException) {
            false
        } catch (e: SecurityException) {
            false
        }

    private fun needAccessibility() {
        toast("Önce 2. izni (Erişilebilirlik hizmeti) aç.")
    }

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
    }

    // ------------------------------------------------------------------ tanılama

    private fun currentDiag(): String {
        val live = LockOverlayService.lastDiag
        if (live.isNotEmpty()) return live
        return Prefs.sp(this).getString(Prefs.DIAG, "") ?: ""
    }

    private fun refreshDiag() {
        val d = currentDiag()
        diagText.text = d.ifEmpty { "Henüz kayıt yok. YouTube çalarken ekranı kilitleyip açınca kayıt oluşur." }
    }

    private fun copyDiag() {
        val d = currentDiag()
        if (d.isEmpty()) {
            toast("Kopyalanacak kayıt yok.")
            return
        }
        val cm = getSystemService(ClipboardManager::class.java)
        val izinler = "bildirim=${notificationAccessGranted()} erişilebilirlik=${accessibilityEnabled()} pil=${batteryUnrestricted()}\n"
        cm.setPrimaryClip(ClipData.newPlainText("YoutubeYek tanılama", izinler + d))
        toast("Kopyalandı")
    }
}
