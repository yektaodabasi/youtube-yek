package com.yekta.youtubeyek

import android.accessibilityservice.AccessibilityService
import android.app.KeyguardManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.content.res.Configuration
import android.graphics.PixelFormat
import android.media.session.MediaSession
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.os.SystemClock
import android.view.ContextThemeWrapper
import android.view.Gravity
import android.view.MotionEvent
import android.view.ViewGroup
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.accessibility.AccessibilityWindowInfo
import android.widget.FrameLayout
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

/**
 * Kilit ekranının üstüne oynatıcı kartını çizen servis.
 *
 * Android, uygulamaların kilit ekranına normal widget koymasına izin vermiyor. Erişilebilirlik
 * servislerinin "erişilebilirlik katmanı" penceresi ise kilit ekranının da üstünde gösterilir;
 * kart bu pencereye yerleştirilir.
 *
 * Kart yalnızca şu durumda görünür: ekran açık + telefon kilitli + YouTube çalıyor (ya da duraklatılmış).
 * Kilit açılınca, ekran kapanınca, şifre ekranı / bildirim paneli açılınca ya da kamera, gelen arama
 * gibi bir uygulama kilit ekranını örtünce kart kaldırılır.
 */
class LockOverlayService : AccessibilityService(), PlayerHub.Listener {

    companion object {
        @Volatile
        var instance: LockOverlayService? = null
            private set

        /** Son tanılama kaydı (uygulama ekranında gösterilir). */
        @Volatile
        var lastDiag: String = ""

        /** Görünür olduğunda kilit ekranını kaplayan sistem görünümleri (şifre ekranı, açık hızlı ayarlar). */
        private val COVER_HINTS = listOf(
            "keyguard_pin_view", "keyguard_password_view", "keyguard_pattern_view",
            "keyguard_sim_pin_view", "keyguard_sim_puk_view", "keyguard_bouncer",
            "bouncer_frame", "pinentry", "passwordentry", "lockpatternview",
            "brightness_slider", "quick_settings_panel", "qs_customize", "qs_detail"
        )
        private const val SYSTEM_UI = "com.android.systemui"
    }

    private val main = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private lateinit var km: KeyguardManager
    private lateinit var power: PowerManager

    private var root: OverlayRoot? = null
    private var params: WindowManager.LayoutParams? = null

    private var connected = false
    private var receiverOn = false
    private var screenOn = true
    private var occluded = false
    private var systemUiCovering = false
    private var touchHidden = false
    private var dismissedToken: MediaSession.Token? = null
    private var previewUntil = 0L
    private var checkPending = false
    private var lastDiagSave = 0L
    private var homeCache: Set<String>? = null

    /** Kartın dışına (kilit ekranının başka yerine) dokunuşu yakalayan kök görünüm. */
    private class OverlayRoot(ctx: Context) : FrameLayout(ctx) {
        var onOutside: (() -> Unit)? = null
        override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
            if (ev.actionMasked == MotionEvent.ACTION_OUTSIDE) {
                onOutside?.invoke()
                return true
            }
            return super.dispatchTouchEvent(ev)
        }
    }

    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        if (key == Prefs.DIAG) return@OnSharedPreferenceChangeListener
        if (key == Prefs.MUSIC) PlayerHub.refresh()
        updateLayout()
        evaluate()
    }

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.action) {
                Intent.ACTION_SCREEN_OFF -> {
                    screenOn = false
                    touchHidden = false
                    occluded = false
                    systemUiCovering = false
                    previewUntil = 0L
                }
                Intent.ACTION_SCREEN_ON -> {
                    screenOn = true
                    touchHidden = false
                    PlayerHub.refresh()
                    scheduleCheck(250L)
                }
                Intent.ACTION_USER_PRESENT -> {
                    touchHidden = false
                    occluded = false
                    systemUiCovering = false
                }
            }
            updateEventMask()
            evaluate()
        }
    }

    private val checkRunnable = Runnable {
        checkPending = false
        inspectWindows()
        evaluate()
    }

    private val previewEnd = Runnable {
        previewUntil = 0L
        evaluate()
    }

    // ------------------------------------------------------------------ servis yaşam döngüsü

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        connected = true
        wm = getSystemService(WindowManager::class.java)
        km = getSystemService(KeyguardManager::class.java)
        power = getSystemService(PowerManager::class.java)
        screenOn = power.isInteractive

        val f = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_SCREEN_OFF)
            addAction(Intent.ACTION_USER_PRESENT)
        }
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(receiver, f, Context.RECEIVER_EXPORTED)
        else registerReceiver(receiver, f)
        receiverOn = true

        Prefs.sp(this).registerOnSharedPreferenceChangeListener(prefListener)
        PlayerHub.addListener(this)
        PlayerHub.start(this)
        updateEventMask()
        evaluate()
    }

    override fun onUnbind(intent: Intent?): Boolean {
        cleanup()
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        cleanup()
        super.onDestroy()
    }

    private fun cleanup() {
        main.removeCallbacksAndMessages(null)
        detach()
        if (receiverOn) {
            try {
                unregisterReceiver(receiver)
            } catch (e: Exception) {
            }
            receiverOn = false
        }
        Prefs.sp(this).unregisterOnSharedPreferenceChangeListener(prefListener)
        PlayerHub.removeListener(this)
        connected = false
        if (instance === this) instance = null
    }

    override fun onInterrupt() {}

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        if (connected) updateLayout()
    }

    override fun onPlayerChanged() {
        if (!connected) return
        val tok = PlayerHub.controller?.sessionToken
        if (dismissedToken != null && tok != dismissedToken) dismissedToken = null
        evaluate()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || !connected) return
        if (event.packageName?.toString() == packageName) return
        if (!screenOn) return
        if (!km.isKeyguardLocked) {
            // Kilit açıldı ama USER_PRESENT gecikti: kartı hemen kaldır.
            if (root != null && SystemClock.uptimeMillis() >= previewUntil) evaluate()
            updateEventMask()
            return
        }
        if (PlayerHub.controller == null && root == null) return
        scheduleCheck(120L)
    }

    // ------------------------------------------------------------------ uygulama ekranından çağrılanlar

    /** Kartı, kilit olmasa da birkaç saniye ekranda göster (konum ayarı için). */
    fun showPreview(ms: Long) {
        previewUntil = SystemClock.uptimeMillis() + ms
        main.removeCallbacks(previewEnd)
        main.postDelayed(previewEnd, ms)
        evaluate()
    }

    fun lockNow() {
        performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN)
    }

    // ------------------------------------------------------------------ gösterme / gizleme kararı

    private fun previewing() = SystemClock.uptimeMillis() < previewUntil

    private fun shouldShow(): Boolean {
        if (previewing()) return true
        if (!Prefs.b(this, Prefs.ENABLED)) return false
        if (!screenOn || !km.isKeyguardLocked) return false
        if (occluded || systemUiCovering || touchHidden) return false
        val c = PlayerHub.controller ?: return false
        if (dismissedToken != null && c.sessionToken == dismissedToken) return false
        return PlayerHub.isShowable(this)
    }

    private fun evaluate() {
        if (!connected) return
        if (shouldShow()) attach() else detach()
    }

    private fun attach() {
        if (root != null) {
            updateLayout()
            return
        }
        val themed = ContextThemeWrapper(this, android.R.style.Theme_Material_NoActionBar)
        val card = PlayerCardView(themed)
        card.sampleWhenEmpty = true
        card.onDismiss = {
            dismissedToken = PlayerHub.controller?.sessionToken
            previewUntil = 0L
            evaluate()
        }
        val r = OverlayRoot(themed)
        r.onOutside = {
            if (!previewing() && Prefs.b(this, Prefs.TOUCH_HIDE)) {
                touchHidden = true
                evaluate()
            }
        }
        r.addView(card, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
        lp.fitInsetsTypes = 0
        lp.title = "YoutubeYek"
        applyGeometry(lp)
        try {
            wm.addView(r, lp)
            root = r
            params = lp
        } catch (e: Exception) {
            root = null
            params = null
        }
    }

    private fun applyGeometry(lp: WindowManager.LayoutParams) {
        val b = wm.currentWindowMetrics.bounds
        val side = (Prefs.i(this, Prefs.SIDE) * resources.displayMetrics.density).roundToInt()
        lp.width = (b.width() - 2 * side).coerceAtLeast(1)
        lp.height = WindowManager.LayoutParams.WRAP_CONTENT
        lp.x = 0
        lp.y = b.height() * Prefs.i(this, Prefs.TOP).coerceIn(0, 90) / 100
    }

    private fun updateLayout() {
        val r = root ?: return
        val lp = params ?: return
        applyGeometry(lp)
        try {
            wm.updateViewLayout(r, lp)
        } catch (e: Exception) {
        }
    }

    private fun detach() {
        val r = root ?: return
        try {
            wm.removeView(r)
        } catch (e: Exception) {
        }
        root = null
        params = null
    }

    // ------------------------------------------------------------------ kilit ekranı durumu

    /** Kilitliyken daha çok olay dinle, kilit açıkken pili yorma. */
    private fun updateEventMask() {
        if (!connected) return
        val info = serviceInfo ?: return
        val locked = screenOn && km.isKeyguardLocked
        val want = if (locked) {
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED or
                AccessibilityEvent.TYPE_WINDOWS_CHANGED or
                AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED
        } else {
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED or AccessibilityEvent.TYPE_WINDOWS_CHANGED
        }
        if (info.eventTypes != want) {
            info.eventTypes = want
            serviceInfo = info
        }
    }

    private fun scheduleCheck(delay: Long) {
        if (checkPending) return
        checkPending = true
        main.postDelayed(checkRunnable, delay)
    }

    private fun launcherPackages(): Set<String> {
        homeCache?.let { return it }
        val set = try {
            val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
            @Suppress("DEPRECATION")
            packageManager.queryIntentActivities(i, 0).map { it.activityInfo.packageName }.toSet()
        } catch (e: Exception) {
            emptySet()
        }
        homeCache = set
        return set
    }

    /**
     * Kilit ekranının üstünde ne var?
     *  - Kamera, gelen arama gibi kilit ekranında açılabilen bir uygulama öndeyse -> örtülü.
     *  - Şifre ekranı ya da açık hızlı ayarlar görünüyorsa -> sistem arayüzü kaplıyor.
     */
    private fun inspectWindows() {
        if (!connected) return
        if (!screenOn || !km.isKeyguardLocked) {
            occluded = false
            systemUiCovering = false
            return
        }
        val ws: List<AccessibilityWindowInfo> = try {
            windows
        } catch (e: Exception) {
            emptyList()
        }
        val homes = launcherPackages()
        var occ = false
        var cover = false
        val ids = LinkedHashSet<String>()
        val wdesc = StringBuilder()
        for (w in ws) {
            val node = try {
                w.root
            } catch (e: Exception) {
                null
            }
            val pkg = node?.packageName?.toString() ?: ""
            wdesc.append("• tip=").append(w.type).append(' ').append(pkg.ifEmpty { "?" })
            if (w.isActive) wdesc.append(" aktif")
            if (w.isFocused) wdesc.append(" odak")
            wdesc.append('\n')
            if (pkg == packageName) continue
            if (w.type == AccessibilityWindowInfo.TYPE_APPLICATION &&
                (w.isActive || w.isFocused) &&
                pkg.isNotEmpty() && pkg != SYSTEM_UI && pkg !in homes
            ) {
                occ = true
            }
            if (node != null && (pkg == SYSTEM_UI || w.type == AccessibilityWindowInfo.TYPE_SYSTEM)) {
                if (scanForCover(node, ids)) cover = true
            }
        }
        occluded = occ
        systemUiCovering = cover
        saveDiag(wdesc, ids, occ, cover)
    }

    private fun scanForCover(start: AccessibilityNodeInfo, ids: MutableSet<String>): Boolean {
        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.addLast(start)
        var seen = 0
        var found = false
        while (queue.isNotEmpty() && seen < 900) {
            val n = queue.removeFirst()
            seen++
            val id = n.viewIdResourceName
            if (id != null && n.isVisibleToUser) {
                val short = id.substringAfter(":id/").lowercase(Locale.ROOT)
                ids.add(short)
                if (COVER_HINTS.any { short.contains(it) }) found = true
            }
            for (i in 0 until n.childCount) {
                val ch = try {
                    n.getChild(i)
                } catch (e: Exception) {
                    null
                }
                if (ch != null) queue.addLast(ch)
            }
        }
        return found
    }

    private fun saveDiag(wdesc: CharSequence, ids: Set<String>, occ: Boolean, cover: Boolean) {
        val sb = StringBuilder()
        sb.append(SimpleDateFormat("HH:mm:ss", Locale.US).format(Date()))
            .append("  kilitli=").append(km.isKeyguardLocked)
            .append("  örtülü=").append(occ)
            .append("  sistemUI=").append(cover)
            .append("  dokunuş=").append(touchHidden)
            .append("  oynatıcı=").append(PlayerHub.controller?.packageName ?: "yok")
            .append('\n')
        sb.append("Pencereler:\n").append(wdesc)
        sb.append("SystemUI kimlikleri (").append(ids.size).append("):\n")
        ids.take(150).forEach { sb.append(it).append('\n') }
        lastDiag = sb.toString()
        val now = SystemClock.uptimeMillis()
        if (now - lastDiagSave > 4000L) {
            lastDiagSave = now
            Prefs.sp(this).edit().putString(Prefs.DIAG, lastDiag).apply()
        }
    }
}
