package com.yekta.youtubeyek

import android.content.ComponentName
import android.content.Context
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSession
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.Handler
import android.os.Looper

/**
 * YouTube'un medya oturumunu (MediaSession) takip eder.
 * Başlık, kanal, kapak, oynatma durumu ve sıradaki liste buradan okunur; tuşlar da buradan YouTube'a gider.
 * Çalışması için "Bildirim erişimi" izni gerekir (Android kuralı).
 */
object PlayerHub {

    fun interface Listener {
        fun onPlayerChanged()
    }

    private val main = Handler(Looper.getMainLooper())
    private val listeners = LinkedHashSet<Listener>()
    private var app: Context? = null
    private var msm: MediaSessionManager? = null
    private var sessionsListenerRegistered = false

    var controller: MediaController? = null
        private set

    private val sessionsListener =
        MediaSessionManager.OnActiveSessionsChangedListener { list -> pick(list) }

    private val callback = object : MediaController.Callback() {
        override fun onPlaybackStateChanged(state: PlaybackState?) = notifyListeners()
        override fun onMetadataChanged(metadata: MediaMetadata?) = notifyListeners()
        override fun onQueueChanged(queue: List<MediaSession.QueueItem>?) = notifyListeners()
        override fun onSessionDestroyed() {
            detachController()
            refresh()
            notifyListeners()
        }
    }

    fun listenerComponent(c: Context) = ComponentName(c, MediaListener::class.java)

    fun start(context: Context) {
        val appCtx = context.applicationContext
        app = appCtx
        if (msm == null) msm = appCtx.getSystemService(MediaSessionManager::class.java)
        if (!sessionsListenerRegistered) {
            try {
                msm?.addOnActiveSessionsChangedListener(sessionsListener, listenerComponent(appCtx), main)
                sessionsListenerRegistered = true
            } catch (e: SecurityException) {
                // Bildirim erişimi henüz verilmemiş.
            }
        }
        refresh()
    }

    fun refresh() {
        val c = app ?: return
        val list = try {
            msm?.getActiveSessions(listenerComponent(c))
        } catch (e: SecurityException) {
            null
        }
        pick(list)
    }

    private fun pick(list: List<MediaController>?) {
        val c = app ?: return
        val allowed = Prefs.allowedPackages(c)
        val candidates = list.orEmpty().filter { it.packageName in allowed }
        val best = candidates.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING }
            ?: candidates.firstOrNull()
        val cur = controller
        if (best == null) {
            if (cur != null) detachController()
            notifyListeners()
            return
        }
        if (cur != null && cur.sessionToken == best.sessionToken) {
            notifyListeners()
            return
        }
        detachController()
        controller = best
        best.registerCallback(callback, main)
        notifyListeners()
    }

    private fun detachController() {
        val cur = controller ?: return
        try {
            cur.unregisterCallback(callback)
        } catch (e: Exception) {
        }
        controller = null
    }

    fun addListener(l: Listener) {
        listeners.add(l)
    }

    fun removeListener(l: Listener) {
        listeners.remove(l)
    }

    private fun notifyListeners() {
        if (Looper.myLooper() != Looper.getMainLooper()) {
            main.post { notifyListeners() }
            return
        }
        for (l in listeners.toList()) l.onPlayerChanged()
    }

    fun isPlaying(st: PlaybackState?): Boolean = when (st?.state) {
        PlaybackState.STATE_PLAYING,
        PlaybackState.STATE_BUFFERING,
        PlaybackState.STATE_CONNECTING,
        PlaybackState.STATE_FAST_FORWARDING,
        PlaybackState.STATE_REWINDING,
        PlaybackState.STATE_SKIPPING_TO_NEXT,
        PlaybackState.STATE_SKIPPING_TO_PREVIOUS,
        PlaybackState.STATE_SKIPPING_TO_QUEUE_ITEM -> true
        else -> false
    }

    /** Kart gösterilmeli mi: çalıyor ya da (ayar izin veriyorsa) duraklatılmış. */
    fun isShowable(c: Context): Boolean {
        val st = controller?.playbackState ?: return false
        if (isPlaying(st)) return true
        return st.state == PlaybackState.STATE_PAUSED && !Prefs.b(c, Prefs.HIDE_PAUSED)
    }
}
