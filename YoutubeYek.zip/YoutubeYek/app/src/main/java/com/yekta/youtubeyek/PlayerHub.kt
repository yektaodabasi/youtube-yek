package com.yekta.youtubeyek

import android.content.ComponentName
import android.content.Context
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSession
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.Handler
import android.os.Looper

/**
 * YouTube'un medya oturumunu (MediaSession) takip eder.
 * Başlık, kanal, kapak, oynatma durumu ve sıradaki liste buradan okunur; tuşlar da buradan YouTube'a gider.
 * Çalışması için "Bildirim erişimi" izni gerekir (Android kuralı).
 */
object PlayerHub {

    fun interface Listener {
        fun onPlayerChanged()
    }

    private val main = Handler(Looper.getMainLooper())
    private val listeners = LinkedHashSet<Listener>()
    private var app: Context? = null
    private var msm: MediaSessionManager? = null
    private var sessionsListenerRegistered = false

    var controller: MediaController? = null
        private set

    private val sessionsListener =
        MediaSessionManager.OnActiveSessionsChangedListener { list -> pick(list) }

    private val callback = object : MediaController.Callback() {
        override fun onPlaybackStateChanged(state: PlaybackState?) {
            onJumpProgress()
            notifyListeners()
        }

        override fun onMetadataChanged(metadata: MediaMetadata?) {
            onJumpProgress()
            notifyListeners()
        }

        override fun onQueueChanged(queue: List<MediaSession.QueueItem>?) {
            onJumpProgress()
            notifyListeners()
        }

        override fun onSessionDestroyed() {
            cancelJump()
            detachController()
            refresh()
            notifyListeners()
        }
    }

    // ------------------------------------------------------------------ listeden şarkı seçme
    //
    // YouTube Music, "şu sıradaki parçaya geç" komutunu (skipToQueueItem) yeni bir liste başlatmak
    // olarak yorumluyor ve eski listeyi atıyor. Bu yüzden hedefe, normal ileri/geri tuşuna gereken
    // sayıda basarak gidiyoruz; her basıştan sonra parçanın gerçekten değişmesini bekliyoruz.

    private var jumpTargetId = -1L
    private var jumpBudget = 0
    private var jumpLastIdx = -1

    private val jumpStep = object : Runnable {
        override fun run() {
            val c = controller
            if (c == null || jumpTargetId < 0) {
                cancelJump()
                return
            }
            val q = c.queue.orEmpty()
            val target = q.indexOfFirst { it.queueId == jumpTargetId }
            val cur = currentIndex(c)
            if (target < 0 || cur < 0 || cur == target || jumpBudget <= 0) {
                cancelJump()
                return
            }
            jumpBudget--
            jumpLastIdx = cur
            if (target > cur) {
                c.transportControls.skipToNext()
            } else {
                // Geri tuşu, parçanın başında değilse önce parçayı başa sarar; bu yüzden önce başa al.
                c.transportControls.seekTo(0L)
                main.postDelayed({ controller?.transportControls?.skipToPrevious() }, 300L)
            }
            // Parça değişmezse de 1.5 sn sonra tekrar dene.
            main.removeCallbacks(this)
            main.postDelayed(this, 1500L)
        }
    }

    /** Listede dokunulan parçaya, listeyi bozmadan git. */
    fun jumpToQueueItem(queueId: Long) {
        val c = controller ?: return
        val q = c.queue.orEmpty()
        val target = q.indexOfFirst { it.queueId == queueId }
        val cur = currentIndex(c)
        if (target < 0) return
        if (cur < 0) {
            // Şu an çalanın yeri bilinmiyorsa başka yol yok.
            c.transportControls.skipToQueueItem(queueId)
            return
        }
        if (target == cur) {
            c.transportControls.seekTo(0L)
            c.transportControls.play()
            return
        }
        cancelJump()
        jumpTargetId = queueId
        jumpBudget = kotlin.math.abs(target - cur) + 3
        main.post(jumpStep)
    }

    private fun onJumpProgress() {
        if (jumpTargetId < 0) return
        val c = controller ?: return
        val cur = currentIndex(c)
        if (cur >= 0 && cur != jumpLastIdx) {
            // Parça değişti: kısa bir bekleyişten sonra bir sonraki adımı at (hedefteyse durur).
            main.removeCallbacks(jumpStep)
            main.postDelayed(jumpStep, 350L)
        }
    }

    private fun cancelJump() {
        jumpTargetId = -1L
        jumpBudget = 0
        jumpLastIdx = -1
        main.removeCallbacks(jumpStep)
    }

    /** Listede şu an çalan parçanın sırası (bilinmiyorsa -1). */
    fun currentIndex(c: MediaController): Int {
        val q = c.queue ?: return -1
        if (q.isEmpty()) return -1
        val activeId = c.playbackState?.activeQueueItemId ?: -1L
        var i = q.indexOfFirst { it.queueId == activeId }
        if (i < 0) {
            val t = c.metadata?.getString(MediaMetadata.METADATA_KEY_TITLE)
            if (t != null) i = q.indexOfFirst { it.description.title?.toString() == t }
        }
        return i
    }

    fun listenerComponent(c: Context) = ComponentName(c, MediaListener::class.java)

    fun start(context: Context) {
        val appCtx = context.applicationContext
        app = appCtx
        if (msm == null) msm = appCtx.getSystemService(MediaSessionManager::class.java)
        if (!sessionsListenerRegistered) {
            try {
                msm?.addOnActiveSessionsChangedListener(sessionsListener, listenerComponent(appCtx), main)
                sessionsListenerRegistered = true
            } catch (e: SecurityException) {
                // Bildirim erişimi henüz verilmemiş.
            }
        }
        refresh()
    }

    fun refresh() {
        val c = app ?: return
        val list = try {
            msm?.getActiveSessions(listenerComponent(c))
        } catch (e: SecurityException) {
            null
        }
        pick(list)
    }

    private fun pick(list: List<MediaController>?) {
        val c = app ?: return
        val allowed = Prefs.allowedPackages(c)
        val candidates = list.orEmpty().filter { it.packageName in allowed }
        val best = candidates.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING }
            ?: candidates.firstOrNull()
        val cur = controller
        if (best == null) {
            if (cur != null) detachController()
            notifyListeners()
            return
        }
        if (cur != null && cur.sessionToken == best.sessionToken) {
            notifyListeners()
            return
        }
        detachController()
        controller = best
        best.registerCallback(callback, main)
        notifyListeners()
    }

    private fun detachController() {
        cancelJump()
        val cur = controller ?: return
        try {
            cur.unregisterCallback(callback)
        } catch (e: Exception) {
        }
        controller = null
    }

    fun addListener(l: Listener) {
        listeners.add(l)
    }

    fun removeListener(l: Listener) {
        listeners.remove(l)
    }

    private fun notifyListeners() {
        if (Looper.myLooper() != Looper.getMainLooper()) {
            main.post { notifyListeners() }
            return
        }
        for (l in listeners.toList()) l.onPlayerChanged()
    }

    fun isPlaying(st: PlaybackState?): Boolean = when (st?.state) {
        PlaybackState.STATE_PLAYING,
        PlaybackState.STATE_BUFFERING,
        PlaybackState.STATE_CONNECTING,
        PlaybackState.STATE_FAST_FORWARDING,
        PlaybackState.STATE_REWINDING,
        PlaybackState.STATE_SKIPPING_TO_NEXT,
        PlaybackState.STATE_SKIPPING_TO_PREVIOUS,
        PlaybackState.STATE_SKIPPING_TO_QUEUE_ITEM -> true
        else -> false
    }

    /** Kart gösterilmeli mi: çalıyor ya da (ayar izin veriyorsa) duraklatılmış. */
    fun isShowable(c: Context): Boolean {
        val st = controller?.playbackState ?: return false
        if (isPlaying(st)) return true
        return st.state == PlaybackState.STATE_PAUSED && !Prefs.b(c, Prefs.HIDE_PAUSED)
    }
}
