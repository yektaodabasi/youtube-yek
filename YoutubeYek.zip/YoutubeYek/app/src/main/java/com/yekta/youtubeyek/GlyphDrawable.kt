package com.yekta.youtubeyek

import android.graphics.Canvas
import android.graphics.ColorFilter
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.drawable.Drawable
import kotlin.math.min

/** Kontrol tuşu simgeleri. Kodla çizilir; boyutu ImageView'e göre ölçeklenir (24 birimlik ızgara). */
class GlyphDrawable(initialKind: Kind, initialColor: Int) : Drawable() {

    enum class Kind { PREV, NEXT, PLAY, PAUSE, CLOSE, CHEVRON_UP, CHEVRON_DOWN, MUSIC }

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = initialColor
    }
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        color = initialColor
    }
    private val path = Path()

    var kind: Kind = initialKind
        set(value) {
            if (field != value) {
                field = value
                invalidateSelf()
            }
        }

    var color: Int = initialColor
        set(value) {
            if (field != value) {
                field = value
                fill.color = value
                stroke.color = value
                invalidateSelf()
            }
        }

    override fun draw(canvas: Canvas) {
        val b = bounds
        val s = min(b.width(), b.height()) / 24f
        if (s <= 0f) return
        val ox = b.exactCenterX() - 12f * s
        val oy = b.exactCenterY() - 12f * s
        fun x(v: Float) = ox + v * s
        fun y(v: Float) = oy + v * s

        path.reset()
        when (kind) {
            Kind.PLAY -> {
                path.moveTo(x(7.5f), y(4.5f))
                path.lineTo(x(19.5f), y(12f))
                path.lineTo(x(7.5f), y(19.5f))
                path.close()
                canvas.drawPath(path, fill)
            }
            Kind.PAUSE -> {
                canvas.drawRoundRect(x(6f), y(4.5f), x(10f), y(19.5f), s, s, fill)
                canvas.drawRoundRect(x(14f), y(4.5f), x(18f), y(19.5f), s, s, fill)
            }
            Kind.NEXT -> {
                path.moveTo(x(5f), y(5.5f))
                path.lineTo(x(15.5f), y(12f))
                path.lineTo(x(5f), y(18.5f))
                path.close()
                canvas.drawPath(path, fill)
                canvas.drawRect(x(16.5f), y(5.5f), x(19f), y(18.5f), fill)
            }
            Kind.PREV -> {
                canvas.drawRect(x(5f), y(5.5f), x(7.5f), y(18.5f), fill)
                path.moveTo(x(19f), y(5.5f))
                path.lineTo(x(8.5f), y(12f))
                path.lineTo(x(19f), y(18.5f))
                path.close()
                canvas.drawPath(path, fill)
            }
            Kind.CLOSE -> {
                stroke.strokeWidth = 2.4f * s
                canvas.drawLine(x(6f), y(6f), x(18f), y(18f), stroke)
                canvas.drawLine(x(18f), y(6f), x(6f), y(18f), stroke)
            }
            Kind.CHEVRON_UP -> {
                stroke.strokeWidth = 2.4f * s
                path.moveTo(x(6f), y(15f))
                path.lineTo(x(12f), y(9f))
                path.lineTo(x(18f), y(15f))
                canvas.drawPath(path, stroke)
            }
            Kind.CHEVRON_DOWN -> {
                stroke.strokeWidth = 2.4f * s
                path.moveTo(x(6f), y(9f))
                path.lineTo(x(12f), y(15f))
                path.lineTo(x(18f), y(9f))
                canvas.drawPath(path, stroke)
            }
            Kind.MUSIC -> {
                canvas.drawCircle(x(8.5f), y(17f), 3.5f * s, fill)
                canvas.drawRect(x(10.5f), y(4f), x(12.5f), y(17f), fill)
                path.moveTo(x(12.5f), y(4f))
                path.lineTo(x(19f), y(6.5f))
                path.lineTo(x(19f), y(10f))
                path.lineTo(x(12.5f), y(7.5f))
                path.close()
                canvas.drawPath(path, fill)
            }
        }
    }

    override fun setAlpha(alpha: Int) {
        fill.alpha = alpha
        stroke.alpha = alpha
        invalidateSelf()
    }

    override fun setColorFilter(colorFilter: ColorFilter?) {
        fill.colorFilter = colorFilter
        stroke.colorFilter = colorFilter
        invalidateSelf()
    }

    @Deprecated("Deprecated in Java")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}
