package com.yekta.youtubeyek

import android.content.Context
import android.content.SharedPreferences
import android.content.res.ColorStateList
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSession
import android.media.session.PlaybackState
import android.os.SystemClock
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.TextUtils
import android.text.style.ForegroundColorSpan
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import java.util.Locale
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

private typealias LP = LinearLayout.LayoutParams

private const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
private const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
private const val MAX_QUEUE_ROWS = 100

/**
 * Sistemdeki YouTube medya kutusuna benzeyen kart:
 * uygulama simgesi + adı, başlık, kanal, kapak, önceki / oynat-duraklat / sonraki / kapat,
 * ilerleme çubuğu ve açılır-kapanır çalma listesi.
 * Hem kilit ekranında hem de uygulama içindeki önizlemede aynı sınıf kullanılır.
 */
class PlayerCardView(context: Context) : LinearLayout(context), PlayerHub.Listener {

    /** Oynatma yokken örnek içerik göster (ayar ekranı önizlemesi ve konum denemesi için). */
    var sampleWhenEmpty = false

    /** Kapat (×) tuşuna basılınca. */
    var onDismiss: (() -> Unit)? = null

    private val density = resources.displayMetrics.density
    private fun dp(v: Float): Float = v * density
    private fun dpi(v: Float): Int = (v * density).roundToInt()

    private var style = Prefs.style(context)

    private val bg = GradientDrawable()
    private val appIcon = ImageView(context)
    private val appName = TextView(context)
    private val title = TextView(context)
    private val artist = TextView(context)
    private val thumb = ImageView(context)
    private val chevronGlyph = GlyphDrawable(GlyphDrawable.Kind.CHEVRON_UP, Color.WHITE)
    private val chevron = ImageView(context)
    private val prevGlyph = GlyphDrawable(GlyphDrawable.Kind.PREV, Color.WHITE)
    private val playGlyph = GlyphDrawable(GlyphDrawable.Kind.PAUSE, Color.WHITE)
    private val nextGlyph = GlyphDrawable(GlyphDrawable.Kind.NEXT, Color.WHITE)
    private val closeGlyph = GlyphDrawable(GlyphDrawable.Kind.CLOSE, Color.WHITE)
    private val btnPrev = ImageView(context)
    private val btnPlay = ImageView(context)
    private val btnNext = ImageView(context)
    private val btnClose = ImageView(context)
    private val progressRow = LinearLayout(context)
    private val elapsed = TextView(context)
    private val seek = SeekBar(context)
    private val total = TextView(context)
    private val queueBox = LinearLayout(context)
    private val divider = View(context)
    private val queueLabel = TextView(context)
    private val queueScroll = ScrollView(context)
    private val queueList = LinearLayout(context)
    private val queueEmpty = TextView(context)

    private var dragging = false
    private var sampleMode = false
    private var lastPkg: String? = null
    private var lastQueueKey: String? = null

    private val ticker = object : Runnable {
        override fun run() {
            updateProgress()
            if (isAttachedToWindow) postDelayed(this, 1000L)
        }
    }

    private val prefListener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
        if (key == Prefs.DIAG) return@OnSharedPreferenceChangeListener
        style = Prefs.style(getContext())
        applyStyle()
        render()
    }

    init {
        orientation = VERTICAL
        background = bg
        setPadding(dpi(20f), dpi(16f), dpi(14f), dpi(12f))

        // ---- Üst bölüm: simge + uygulama adı, başlık, kanal | kapak | aç-kapa oku
        val top = LinearLayout(context).apply {
            orientation = HORIZONTAL
            gravity = Gravity.TOP
        }
        val left = LinearLayout(context).apply { orientation = VERTICAL }
        val header = LinearLayout(context).apply {
            orientation = HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        appIcon.scaleType = ImageView.ScaleType.FIT_CENTER
        header.addView(appIcon, LP(dpi(22f), dpi(22f)))
        appName.maxLines = 1
        appName.ellipsize = TextUtils.TruncateAt.END
        header.addView(appName, LP(WRAP, WRAP).apply { marginStart = dpi(12f) })
        left.addView(header, LP(MATCH, WRAP))

        title.maxLines = 2
        title.ellipsize = TextUtils.TruncateAt.END
        title.typeface = Typeface.DEFAULT_BOLD
        left.addView(title, LP(MATCH, WRAP).apply {
            marginStart = dpi(34f)
            topMargin = dpi(12f)
        })
        artist.maxLines = 1
        artist.ellipsize = TextUtils.TruncateAt.END
        left.addView(artist, LP(MATCH, WRAP).apply {
            marginStart = dpi(34f)
            topMargin = dpi(3f)
        })
        top.addView(left, LP(0, WRAP, 1f))

        thumb.scaleType = ImageView.ScaleType.CENTER_CROP
        thumb.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, dp(8f))
            }
        }
        thumb.clipToOutline = true
        top.addView(thumb, LP(dpi(66f), dpi(50f)).apply {
            marginStart = dpi(10f)
            topMargin = dpi(2f)
        })

        chevron.setImageDrawable(chevronGlyph)
        chevron.setPadding(dpi(7f), dpi(7f), dpi(7f), dpi(7f))
        chevron.background = buttonRipple()
        chevron.contentDescription = "Çalma listesini aç/kapat"
        chevron.setOnClickListener { Prefs.put(getContext(), Prefs.QUEUE, !style.queueOpen) }
        top.addView(chevron, LP(dpi(36f), dpi(36f)).apply { marginStart = dpi(6f) })
        addView(top, LP(MATCH, WRAP))

        // ---- Kontrol tuşları
        val controls = LinearLayout(context).apply {
            orientation = HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val buttons = listOf(
            Triple(btnPrev, prevGlyph, "Önceki"),
            Triple(btnPlay, playGlyph, "Oynat / duraklat"),
            Triple(btnNext, nextGlyph, "Sonraki"),
            Triple(btnClose, closeGlyph, "Kapat")
        )
        for ((v, g, desc) in buttons) {
            v.setImageDrawable(g)
            v.setPadding(dpi(10f), dpi(10f), dpi(10f), dpi(10f))
            v.background = buttonRipple()
            v.contentDescription = desc
            controls.addView(v, LP(dpi(48f), dpi(48f)).apply { marginEnd = dpi(14f) })
        }
        addView(controls, LP(WRAP, WRAP).apply {
            marginStart = dpi(22f)
            topMargin = dpi(8f)
        })

        btnPrev.setOnClickListener { PlayerHub.controller?.transportControls?.skipToPrevious() }
        btnNext.setOnClickListener { PlayerHub.controller?.transportControls?.skipToNext() }
        btnPlay.setOnClickListener {
            val c = PlayerHub.controller ?: return@setOnClickListener
            if (PlayerHub.isPlaying(c.playbackState)) c.transportControls.pause() else c.transportControls.play()
        }
        btnClose.setOnClickListener {
            val c = PlayerHub.controller
            if (c != null) {
                val custom = c.playbackState?.customActions?.firstOrNull { a ->
                    val s = a.action.lowercase(Locale.ROOT)
                    s.contains("close") || s.contains("dismiss") || s.contains("stop")
                }
                if (custom != null) c.transportControls.sendCustomAction(custom, null)
                else c.transportControls.stop()
            }
            onDismiss?.invoke()
        }

        // ---- İlerleme çubuğu
        progressRow.orientation = HORIZONTAL
        progressRow.gravity = Gravity.CENTER_VERTICAL
        progressRow.addView(elapsed, LP(WRAP, WRAP))
        seek.setPadding(dpi(12f), 0, dpi(12f), 0)
        seek.splitTrack = false
        progressRow.addView(seek, LP(0, dpi(28f), 1f))
        progressRow.addView(total, LP(WRAP, WRAP))
        addView(progressRow, LP(MATCH, WRAP).apply {
            marginStart = dpi(34f)
            marginEnd = dpi(6f)
        })
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) elapsed.text = fmt(progress * 1000L)
            }

            override fun onStartTrackingTouch(sb: SeekBar?) {
                dragging = true
            }

            override fun onStopTrackingTouch(sb: SeekBar?) {
                dragging = false
                val p = sb?.progress ?: return
                PlayerHub.controller?.transportControls?.seekTo(p * 1000L)
            }
        })

        // ---- Çalma listesi
        queueBox.orientation = VERTICAL
        queueBox.addView(divider, LP(MATCH, max(1, dpi(0.8f))).apply { topMargin = dpi(6f) })
        queueLabel.typeface = Typeface.DEFAULT_BOLD
        queueBox.addView(queueLabel, LP(MATCH, WRAP).apply {
            topMargin = dpi(8f)
            marginStart = dpi(4f)
            bottomMargin = dpi(2f)
        })
        queueList.orientation = VERTICAL
        queueScroll.isVerticalScrollBarEnabled = true
        queueScroll.addView(queueList, FrameLayout.LayoutParams(MATCH, WRAP))
        queueBox.addView(queueScroll, LP(MATCH, dpi(38f) * 3))
        queueBox.addView(queueEmpty, LP(MATCH, WRAP).apply {
            marginStart = dpi(4f)
            topMargin = dpi(2f)
            bottomMargin = dpi(4f)
        })
        addView(queueBox, LP(MATCH, WRAP))

        applyStyle()
    }

    // ------------------------------------------------------------------ yaşam döngüsü

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        Prefs.sp(context).registerOnSharedPreferenceChangeListener(prefListener)
        PlayerHub.addListener(this)
        style = Prefs.style(context)
        applyStyle()
        render()
        removeCallbacks(ticker)
        post(ticker)
    }

    override fun onDetachedFromWindow() {
        Prefs.sp(context).unregisterOnSharedPreferenceChangeListener(prefListener)
        PlayerHub.removeListener(this)
        removeCallbacks(ticker)
        super.onDetachedFromWindow()
    }

    override fun onPlayerChanged() = render()

    // ------------------------------------------------------------------ görünüm

    private fun buttonRipple(): RippleDrawable =
        RippleDrawable(ColorStateList.valueOf(if (style.light) 0x22000000 else 0x33FFFFFF), null, null)

    private fun rowRipple(): RippleDrawable =
        RippleDrawable(
            ColorStateList.valueOf(if (style.light) 0x22000000 else 0x33FFFFFF),
            null,
            ColorDrawable(Color.WHITE)
        )

    private fun rowHeight(): Int = dpi(38f * style.textPct / 100f)

    private fun applyStyle() {
        val s = style
        val alpha = ((100 - s.transparencyPct) * 255 / 100).coerceIn(0, 255)
        bg.cornerRadius = dp(26f)
        bg.setColor((s.bg and 0x00FFFFFF) or (alpha shl 24))

        val k = s.textPct / 100f
        appName.setTextColor(s.primary)
        appName.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f * k)
        title.setTextColor(s.primary)
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 19f * k)
        artist.setTextColor(s.secondary)
        artist.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f * k)
        for (t in listOf(elapsed, total)) {
            t.setTextColor(s.secondary)
            t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f * k)
        }
        queueLabel.setTextColor(s.secondary)
        queueLabel.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f * k)
        queueEmpty.setTextColor(s.secondary)
        queueEmpty.setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f * k)
        divider.setBackgroundColor((s.secondary and 0x00FFFFFF) or (0x40 shl 24))

        for (g in listOf(prevGlyph, playGlyph, nextGlyph, closeGlyph, chevronGlyph)) g.color = s.primary

        seek.progressTintList = ColorStateList.valueOf(Prefs.ACCENT)
        seek.thumbTintList = ColorStateList.valueOf(Prefs.ACCENT)
        seek.progressBackgroundTintList = ColorStateList.valueOf(s.secondary)

        queueBox.visibility = if (s.queueOpen) VISIBLE else GONE
        chevronGlyph.kind = if (s.queueOpen) GlyphDrawable.Kind.CHEVRON_UP else GlyphDrawable.Kind.CHEVRON_DOWN
        val lp = queueScroll.layoutParams
        if (lp != null) {
            lp.height = rowHeight() * s.rows
            queueScroll.layoutParams = lp
        }
        lastQueueKey = null
    }

    /** Oynatıcıdaki son durumu karta yansıtır. */
    fun render() {
        val c = PlayerHub.controller
        if (c == null) {
            if (sampleWhenEmpty) renderSample()
            return
        }
        sampleMode = false
        bindApp(c.packageName)

        val md = c.metadata
        val t = md?.getString(MediaMetadata.METADATA_KEY_TITLE)
            ?: md?.description?.title?.toString()
            ?: ""
        val a = md?.getString(MediaMetadata.METADATA_KEY_ARTIST)
            ?: md?.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST)
            ?: md?.description?.subtitle?.toString()
        title.text = t
        artist.text = a ?: ""
        artist.visibility = if (a.isNullOrBlank()) GONE else VISIBLE

        val art = artOf(md)
        if (art != null) {
            thumb.setImageBitmap(art)
            thumb.visibility = VISIBLE
        } else {
            thumb.setImageDrawable(null)
            thumb.visibility = GONE
        }

        val st = c.playbackState
        playGlyph.kind = if (PlayerHub.isPlaying(st)) GlyphDrawable.Kind.PAUSE else GlyphDrawable.Kind.PLAY
        val acts = st?.actions ?: 0L
        setEnabledLook(btnPrev, has(acts, PlaybackState.ACTION_SKIP_TO_PREVIOUS))
        setEnabledLook(btnNext, has(acts, PlaybackState.ACTION_SKIP_TO_NEXT))
        setEnabledLook(btnPlay, true)
        setEnabledLook(btnClose, true)

        updateProgress()
        bindQueue(c)
    }

    private fun artOf(md: MediaMetadata?): Bitmap? {
        if (md == null) return null
        return md.getBitmap(MediaMetadata.METADATA_KEY_ART)
            ?: md.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
            ?: md.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)
            ?: md.description.iconBitmap
    }

    private fun bindApp(pkg: String) {
        if (pkg == lastPkg) return
        lastPkg = pkg
        val pm = context.packageManager
        try {
            @Suppress("DEPRECATION")
            val ai = pm.getApplicationInfo(pkg, 0)
            appName.text = pm.getApplicationLabel(ai)
            appIcon.setImageDrawable(pm.getApplicationIcon(ai))
        } catch (e: Exception) {
            appName.text = if (pkg in Prefs.MUSIC_PKGS) "YouTube Music" else "YouTube"
            appIcon.setImageDrawable(GlyphDrawable(GlyphDrawable.Kind.MUSIC, Prefs.ACCENT))
        }
    }

    private fun has(acts: Long, a: Long): Boolean = acts == 0L || (acts and a) != 0L

    private fun setEnabledLook(v: View, enabled: Boolean) {
        v.isEnabled = enabled
        v.alpha = if (enabled) 1f else 0.35f
    }

    private fun updateProgress() {
        if (sampleMode) return
        val c = PlayerHub.controller
        val st = c?.playbackState
        val dur = c?.metadata?.getLong(MediaMetadata.METADATA_KEY_DURATION) ?: 0L
        if (c == null || st == null || dur <= 0L) {
            progressRow.visibility = GONE
            return
        }
        progressRow.visibility = VISIBLE
        var pos = st.position
        if (st.state == PlaybackState.STATE_PLAYING && st.lastPositionUpdateTime > 0L) {
            val dt = SystemClock.elapsedRealtime() - st.lastPositionUpdateTime
            pos += (dt * st.playbackSpeed).toLong()
        }
        pos = pos.coerceIn(0L, dur)
        seek.isEnabled = has(st.actions, PlaybackState.ACTION_SEEK_TO)
        if (!dragging) {
            seek.max = (dur / 1000L).toInt()
            seek.progress = (pos / 1000L).toInt()
            elapsed.text = fmt(pos)
        }
        total.text = fmt(dur)
    }

    private fun fmt(ms: Long): String {
        val s = ms / 1000L
        val h = s / 3600L
        val m = (s % 3600L) / 60L
        val sec = s % 60L
        return if (h > 0) String.format(Locale.US, "%d:%02d:%02d", h, m, sec)
        else String.format(Locale.US, "%d:%02d", m, sec)
    }

    private fun bindQueue(c: MediaController) {
        val q: List<MediaSession.QueueItem> = c.queue ?: emptyList()
        if (q.isEmpty()) {
            if (lastQueueKey != "empty") {
                queueList.removeAllViews()
                lastQueueKey = "empty"
            }
            queueLabel.text = "Çalma listesi"
            queueScroll.visibility = GONE
            queueEmpty.visibility = VISIBLE
            queueEmpty.text = "Liste bilgisi yok — YouTube bu oynatmada sıradaki listeyi paylaşmıyor."
            return
        }
        queueScroll.visibility = VISIBLE
        queueEmpty.visibility = GONE

        val activeId = c.playbackState?.activeQueueItemId ?: -1L
        var cur = q.indexOfFirst { it.queueId == activeId }
        if (cur < 0) {
            val t = c.metadata?.getString(MediaMetadata.METADATA_KEY_TITLE)
            if (t != null) cur = q.indexOfFirst { it.description.title?.toString() == t }
        }
        queueLabel.text = if (cur >= 0) "Çalma listesi · ${cur + 1}/${q.size}" else "Çalma listesi · ${q.size}"

        val from = max(0, cur - 1)
        val to = min(q.size, from + MAX_QUEUE_ROWS)
        val key = "${q.size}|${q[0].queueId}|${q[q.size - 1].queueId}|$cur|$from"
        if (key == lastQueueKey) return
        lastQueueKey = key

        queueList.removeAllViews()
        var curRow: View? = null
        for (i in from until to) {
            val item = q[i]
            val row = makeRow(i + 1, item.description.title, item.description.subtitle, i == cur)
            val id = item.queueId
            row.setOnClickListener { PlayerHub.controller?.transportControls?.skipToQueueItem(id) }
            queueList.addView(row, LP(MATCH, rowHeight()))
            if (i == cur) curRow = row
        }
        val target = curRow
        queueScroll.post { queueScroll.scrollTo(0, target?.top ?: 0) }
    }

    private fun makeRow(n: Int, t: CharSequence?, sub: CharSequence?, current: Boolean): TextView {
        val s = style
        val tv = TextView(context)
        tv.maxLines = 1
        tv.ellipsize = TextUtils.TruncateAt.END
        tv.gravity = Gravity.CENTER_VERTICAL
        tv.setPadding(dpi(6f), 0, dpi(6f), 0)
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f * s.textPct / 100f)
        val sb = SpannableStringBuilder()
        appendColored(sb, if (current) "▶  " else "$n  ", if (current) Prefs.ACCENT else s.secondary)
        appendColored(sb, t?.toString() ?: "—", if (current) Prefs.ACCENT else s.primary)
        if (!sub.isNullOrBlank()) appendColored(sb, "  ·  $sub", s.secondary)
        tv.text = sb
        if (current) tv.typeface = Typeface.DEFAULT_BOLD
        tv.background = rowRipple()
        return tv
    }

    private fun appendColored(sb: SpannableStringBuilder, text: String, color: Int) {
        val start = sb.length
        sb.append(text)
        sb.setSpan(ForegroundColorSpan(color), start, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
    }

    /** Oynatma yokken önizleme içeriği. */
    private fun renderSample() {
        sampleMode = true
        lastPkg = null
        appName.text = "YouTube"
        appIcon.setImageDrawable(GlyphDrawable(GlyphDrawable.Kind.MUSIC, Prefs.ACCENT))
        title.text = "Video ya da şarkı adı"
        artist.text = "Kanal adı"
        artist.visibility = VISIBLE
        thumb.setImageDrawable(
            GradientDrawable(
                GradientDrawable.Orientation.TL_BR,
                intArrayOf(0xFF4A4F5C.toInt(), 0xFF1E222B.toInt())
            )
        )
        thumb.visibility = VISIBLE
        playGlyph.kind = GlyphDrawable.Kind.PAUSE
        for (v in listOf(btnPrev, btnPlay, btnNext, btnClose)) setEnabledLook(v, true)

        progressRow.visibility = VISIBLE
        seek.isEnabled = false
        seek.max = 225
        seek.progress = 72
        elapsed.text = fmt(72_000L)
        total.text = fmt(225_000L)

        queueScroll.visibility = VISIBLE
        queueEmpty.visibility = GONE
        queueLabel.text = "Çalma listesi · 2/12"
        if (lastQueueKey != "sample") {
            lastQueueKey = "sample"
            queueList.removeAllViews()
            val names = listOf("Önceki video", "Şimdi çalan", "Sıradaki video", "Sonraki video", "Listedeki diğer video")
            names.forEachIndexed { i, n ->
                queueList.addView(makeRow(i + 1, n, "Kanal", i == 1), LP(MATCH, rowHeight()))
            }
        }
    }
}
