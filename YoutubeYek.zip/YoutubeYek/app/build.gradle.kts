plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.yekta.youtubeyek"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.yekta.youtubeyek"
        minSdk = 30          // Android 11
        targetSdk = 34
        versionCode = 3
        versionName = "1.2"
    }

    // Her derlemede aynı imza: yeni APK eskisinin üzerine kurulur (kaldırmaya gerek kalmaz).
    signingConfigs {
        getByName("debug") {
            storeFile = file("youtubeyek-debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }

    buildTypes {
        release { isMinifyEnabled = false }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
}
