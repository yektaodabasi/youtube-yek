# YoutubeYek

YouTube / YouTube Music çalarken kilit ekranında (saat ile parmak izi arasında) oynatıcı kartı gösterir:
başlık, kanal, kapak, önceki / oynat-duraklat / sonraki / kapat, ilerleme çubuğu ve çalma listesi.

## Derleme (GitHub Actions)
1. GitHub'da yeni bir depo aç (ör. `kilit-yek`), "Add README" işaretli.
2. `YoutubeYek.zip`'i depoya yükle (Add file → Upload files). Adı tam olarak `YoutubeYek.zip` olmalı.
3. Add file → Create new file: `.github/workflows/build.yml`, içine `build.yml`'yi yapıştır.
4. Actions bitince Releases → `app-debug.apk`'yı indirip kur.
   Sonraki sürümlerde sadece zip'i aynı adla yeniden yükle; imza sabit olduğu için yeni APK eskinin üzerine kurulur.

## İlk kurulum (telefonda)
1. Uygulamayı aç → 1. Bildirim erişimi → Aç → YoutubeYek'i aç.
2. 2. Erişilebilirlik hizmeti → Aç → "YoutubeYek kilit ekranı oynatıcı"yı aç.
3. 3. Pil kısıtlaması → Kaldır.
4. Kilit ekranında YouTube'un kendi kutusu da çıkmasın istiyorsan:
   Ayarlar → Bildirimler ve Durum çubuğu → "Bildirimi kilit ekranında göster" kapat.

## Nasıl çalışır
- `MediaListener` (bildirim dinleyici): Android başka uygulamanın medya oturumunu yalnızca bu izinle açar.
- `PlayerHub`: YouTube'un MediaSession'ını izler; tuşlar YouTube'u doğrudan kontrol eder.
- `LockOverlayService` (erişilebilirlik): kartı erişilebilirlik katmanına koyar; bu katman kilit ekranının üstündedir.
  Kart yalnızca ekran açık + kilitli + YouTube çalarken görünür; kilit açılınca, ekran kapanınca,
  şifre ekranı / bildirim paneli açılınca ya da kamera, arama gibi bir uygulama öne gelince kaldırılır.
- `PlayerCardView`: kartın kendisi (uygulama içi önizlemede de aynısı).
- `MainActivity`: izinler, şeffaflık, renk, yazı boyutu, konum, liste ayarları ve tanılama.

Paket: `com.yekta.youtubeyek` · minSdk 30 (Android 11) · harici kütüphane yok.
